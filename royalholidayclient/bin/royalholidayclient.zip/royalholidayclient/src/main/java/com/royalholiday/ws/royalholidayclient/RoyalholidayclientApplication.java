package com.royalholiday.ws.royalholidayclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoyalholidayclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoyalholidayclientApplication.class, args);
	}

}
